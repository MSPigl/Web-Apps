<?
function db_connect() 
{
  return new mysqli("localhost", "sienasel_sbxusr", "Sandbox@)!&", "sienasel_sandbox");
}	
?>	
