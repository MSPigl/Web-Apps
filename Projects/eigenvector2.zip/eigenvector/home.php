<? session_start();


?>

<html>
    <? echo 'Placeholder'; ?>
</html>