<?
session_start();

session_destroy();

unset($_SESSION);

header("Location: http://s996715.sienasellbacks.com/project4/eigenvector/eigenvector/");

die("Session Destroyed");
?>